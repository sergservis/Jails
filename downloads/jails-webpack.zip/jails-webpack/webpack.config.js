var path     = require('path'),
    glob     = require('glob'),
	optimize = require('webpack').optimize,
	dev = isDev();

module.exports = {

	devtool	:dev?'source-map' :null,

	entry	:entries({
		main:[ 'jails', 'riot', './es6/main'+ (dev?'.dev':'') ]
	}),

	resolve	:{
		alias :{
			scriptjs:'scriptjs/dist/script.min',
			jails 	:'jails-js/source/jails.min',
			mods  	:'jails-modules',
			comps 	:'jails-components',
			riot	:'riot/riot.min'
		}
	},

    output	:{
		path: __dirname + '/js-min',
        filename: '[name].min.js'
    },

	plugins	:[ new optimize.CommonsChunkPlugin('main', 'main.min.js') ].concat(
		dev?[]: new optimize.UglifyJsPlugin({
			compress :{ warnings:false },
			minimize :true}
		)
	),

    module	:	{
        loaders: [{
			loader: 'babel',
			test: /\.js$/,
			exclude: /node_modules/,
			query:{ presets:['es2015']}
		}]
    }
};

function entries( main ){
	return glob.sync('./es6/apps/*.js').reduce(function(x, file){
		var name 	= path.basename(file, '.js');
		x[ name ] = './es6/apps/' + name;
		return x;
	}, main)
}

function isDev(){
	return !!process.argv.filter(function(item){
	    return item == '--dev';
	}).length
}
