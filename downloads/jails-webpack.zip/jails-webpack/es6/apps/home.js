import 'comps/riot-view/riot-view'
import '../components/button'

import jails from 'jails'

jails.app('home', function( html, data ){

	let view = this.x('.view')

	this.init = ()=>{
		this.listen('button:wasClicked', wasClicked)
	}

	let wasClicked = (e, option)=>{

		view('update', {
			title :'Jails is ready!!!',
			times :option.times
		})
	}

})
