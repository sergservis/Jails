import jails from 'jails'
import scriptjs from 'scriptjs'

scriptjs([

	'//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js',
	appscript.getAttribute('data-main')

], () => {
	jails.start()
})
