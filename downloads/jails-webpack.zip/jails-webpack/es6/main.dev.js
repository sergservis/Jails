import jails from 'jails'
import logger from 'mods/logger/logger'
import scriptjs from 'scriptjs'

scriptjs([
	//jQuery is loaded in case you need it =)
	'//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js',
	appscript.getAttribute('data-main')

], () => {
	logger()
	jails.start()
})
