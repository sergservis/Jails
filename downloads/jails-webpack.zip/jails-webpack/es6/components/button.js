import jails from 'jails'

jails.component('button', function( html, anno ){

	let times = 1

    this.init = ()=>{
		this.on('click', log)
	}

	let log = (e)=>{
		this.emit('wasClicked', { times :times++ })
		e.preventDefault()
	}

})
