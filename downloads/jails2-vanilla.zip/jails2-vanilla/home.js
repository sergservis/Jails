jails('home', function( component, html, data ){

	var span = document.getElementById('times');

	return {

		init :function(){
			component.listen('button:wasClicked', wasClicked);
		},

		wasClicked :function(e, option){
			span.innerHTML = option.times;
		}
	};
});
