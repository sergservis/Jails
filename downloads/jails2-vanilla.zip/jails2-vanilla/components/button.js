jails('button', function( component, html, anno ){

	var times = 1;

	return {
		init :function(){
			component.on('click', this.log);
		},

		log: function(e){
			console.log( e );
			component.emit('wasClicked', { times :++times });
		}
	}
});
