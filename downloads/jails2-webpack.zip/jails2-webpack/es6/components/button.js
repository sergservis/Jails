import jails from 'jails'

jails('button', ( component, html, anno ) =>{

	let times = 1

	return {

		init (){
			component.on('click', this.log)
		},

		log(e){
			component.emit('wasClicked', { times :times++ })
			e.preventDefault()
		}
	}

})
