import jails from 'jails'
import scriptjs from 'scriptjs'
import logger from 'mods/logger/logger'

let jquery = 'node_modules/jquery/dist/jquery.min.js'
let jquerycdn = '//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js'
let app = appscript.getAttribute('data-main')
let dependencies = [app]

scriptjs( jquerycdn, ()=>{

	if( !window.jQuery ){
		dependencies.unshift( jquery )
	}

	scriptjs(dependencies, ()=>{
		logger()
		jails.start()
	})
})
