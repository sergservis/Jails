import 'comps/view/view'
import '../components/button'

import jails from 'jails'

jails('home', ( component, html, data )=>{

	let view = component.get('.view')

	return {

		init(){
			component.listen('button:wasClicked', this.wasClicked)
		},

		wasClicked(e, option){
			view('update', {
				title :'Jails is ready!!!',
				times :option.times
			})
		}
	}
})
