# Jails + Webpack Setup

This demo doesn't use `gulp` or `grunt`, it's using npm commands to run tasks.

## webpack.config.js

Webpack was configured to bundle a file called `main.js` with common libraries such as `riot` for templating,
`jails` and `scriptjs` for asynchronous js calls.

The `main` file will load up the application file using `scriptjs` loading asynchronously to a better performance in page load.

All applications bundles will be created automatically you just need to create an app and place it on `apps` folder.

## Installing
	npm install

## Watching
	npm run watch:js

## Building
	npm run build:js
