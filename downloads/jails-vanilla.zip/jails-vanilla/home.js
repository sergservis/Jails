jails.app('home', function( html, data ){

	var span = document.getElementById('times');

	this.init = function(){
		this.listen('button:wasClicked', wasClicked);
	};

	function wasClicked(e, option){
		span.innerHTML = option.times;
	}

});
