jails.component('button', function( html, anno ){

	var times = 1, self = this;

    this.init = function(){
		this.on('click', log);
	};

	function log(e){
		console.log( e );
		self.emit('wasClicked', { times :++times });
	}

});
