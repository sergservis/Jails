import vdom from 'jails-modules/vdom'

export default vdom(( state )=>{
	return (
		<p>
			<span>{state.name}</span>
		</p>
	)
})
