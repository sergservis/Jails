import template from './template.jsx'

export default ( component, element, props )=>{

	component.init = ()=>{
		console.info('example component loaded')
	}
}
