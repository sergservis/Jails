import jails 	from 'jails'
import example 	from 'components/example'

jails('example', example)
