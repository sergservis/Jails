import jails 	from 'jails'
import scriptjs from 'scriptjs'

let mainscript 	= document.getElementById('main-script')
let app 		= mainscript.getAttribute('data-application')

scriptjs([ app ], ()=>{
	jails.start()
})
