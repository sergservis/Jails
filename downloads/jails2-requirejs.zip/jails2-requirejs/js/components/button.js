define([

	'jails'

], function( jails ){

	jails('button', function( component, html, anno ){

		var times = 1;

		component.init = function(){
			component.on('click', log);
		}

		function log(e){
			component.emit('wasClicked', { times :times++ });
			e.preventDefault();
		}

	});
})
