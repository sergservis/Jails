define([
	'jails',
	'../components/button',
	'comps/view/view'
], function( jails ){

	jails('home', function( component, html, data ){

		var view = component.get('.view');

		return {

			init :function(){
				component.listen('button:wasClicked', this.wasClicked);
			},

			wasClicked :function(e, option){

				view('update', {
					title :'Jails is ready!!!',
					times :option.times
				})
			}

		};

	})

});
