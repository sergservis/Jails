var requirejs = require('requirejs');
var path = require('path');
var glob = require('glob');
var dev = isDev();

global.jailsglobal = {};

glob('js/apps/*.js', null, function (err, files) {

   files.forEach(function( filepath ){

	   requirejs.optimize({
		   name: 'apps/' + path.basename( filepath, '.js' ),
		   out: 'js-min/' + path.basename( filepath, '.js' ) + '.min.js',
		   mainConfigFile : ['js/main' + (dev?'.dev':'') +'.js']
	   })
   });
});

function isDev(){
	return !!process.argv.filter(function(item){
	    return item == '--dev';
	}).length
}
