# Jails + Requirejs Setup

This demo doesn't use `gulp` or `grunt`, it's using npm commands to run tasks.

## requirejs.config.js

There are many many patterns to setup `requirejs`, in this example, `main.js` is a requirejs config, it's used for bundle modules by r.js. Jails is just a UMD module, set your requirejs project in a way that better fits to your requirements, this is just a sample, use the way it is or as an expiration for creating a different setup.

## Installing
	npm install

## Compile with logs and pretty code
	npm run dev:js

## Building without logs and uglified
	npm run build:js
