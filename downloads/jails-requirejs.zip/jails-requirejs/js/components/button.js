define([

	'jails'

], function( jails ){

	jails.component('button', function( html, anno ){

		var times = 1;
		var cp = this;

		this.init = function(){
			this.on('click', log);
		}

		function log(e){
			cp.emit('wasClicked', { times :times++ });
			e.preventDefault();
		}

	});
})
