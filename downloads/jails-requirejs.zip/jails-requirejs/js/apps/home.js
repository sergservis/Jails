define([
	'jails',
	'../components/button',
	'comps/riot-view/riot-view'
], function( jails ){

	jails.app('home', function( html, data ){

		var view = this.x('.view');

		this.init = function(){
			this.listen('button:wasClicked', wasClicked);
		};

		function wasClicked(e, option){

			view('update', {
				title :'Jails is ready!!!',
				times :option.times
			})
		}

	})

});
