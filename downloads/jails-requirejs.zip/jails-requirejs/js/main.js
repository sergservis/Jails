require.config({

	baseUrl :'',
	deps    :['jails', 'jquery', jailsglobal.app],
	include	:['main'],

	paths   :{

		jails		:'../node_modules/jails-js/source/jails.min',
		mods		:'../node_modules/jails-modules',
		comps		:'../node_modules/jails-components',
		logger		:'../node_modules/jails-modules/logger/logger',
		riot		:'../node_modules/riot/riot.min',
		jquery 		:'//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min'
	},

	callback :function( jails ){
		jails.start();
	}
});
